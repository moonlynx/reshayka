define({
  correctAnswers: 0,
  incorrectAnswers: 0,
  motiv: "",
  example: "",
  answer: ""
});
