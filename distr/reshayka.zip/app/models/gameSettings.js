define({
  operators: ["+", "-"],
  maxExampleNumber: 20,
  maxNumberForAll: true,
  addMaxNumber: 10,
  subMaxNumber: 10,
  mulMaxNumber: 10,
  divMaxNumber: 10
});