define({
	rootId: "game-board",
	styleId: "game-style",
	styles: {
		xlarge: "./style/style-xlarge.css",
		large: "./style/style-large.css",
		medium: "./style/style-medium.css",
		small: "./style/style-small.css"
	}
});
