requirejs.config({
	baseUrl : "./app/",
	deps: ["styleSelector", "gameInit"]
});
